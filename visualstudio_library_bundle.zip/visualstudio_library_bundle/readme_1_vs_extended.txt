The vs_extended bundle was constructed for ease of use in the Saxion C++ 3D Rendering course.
See the MicroEngine VS2017 readme for more info on how to use this bundle.

Current versions:
-----------------
GLM 0.9.8.5
Glew 2.1.0
SFML 2.4.2
